(function () {
  document.addEventListener("DOMContentLoaded", function () {
    // Make each section header (e.g. "12. Security Verification") clickable,
    // navigating to its first child page, while still keeping every child
    // (12.1, 12.2, ...) visible as its own row.
    document.querySelectorAll(".md-nav--primary .md-nav__item--nested > label.md-nav__link").forEach(function (label) {
      var nested = label.parentElement.querySelector(":scope > nav.md-nav");
      if (!nested) return;
      var firstLink = nested.querySelector("a.md-nav__link");
      if (!firstLink) return;

      var text = label.querySelector(".md-ellipsis");
      if (!text) return;
      text.style.cursor = "pointer";
      text.addEventListener("click", function (e) {
        e.preventDefault();
        e.stopPropagation();
        window.location.href = firstLink.getAttribute("href");
      });
    });

    // Bold + vertical-bar highlight for the active chapter, and for its
    // parent section header when the active page is nested under one.
    var active = document.querySelector(".md-nav--primary .md-nav__link--active");
    if (active) {
      var el = active.closest("li.md-nav__item");
      while (el) {
        var ownLabelOrLink = el.querySelector(":scope > label.md-nav__link, :scope > a.md-nav__link");
        if (ownLabelOrLink) ownLabelOrLink.classList.add("md-nav__link--chapter-active");
        var parentNav = el.parentElement && el.parentElement.closest("li.md-nav__item");
        el = parentNav;
      }
    } else {
      // No nav entry is active -- we're on the homepage (it's intentionally
      // left out of nav), so treat the sidebar site title as the active one.
      var homeLabel = document.querySelector(".md-nav--primary > label.md-nav__title[for='__drawer']");
      if (homeLabel) homeLabel.classList.add("md-nav__link--chapter-active");
    }

    // Make the site title (header + sidebar) clickable to the homepage,
    // matching the existing logo icon link.
    var headerLogo = document.querySelector(".md-header__button.md-logo");
    var headerTitle = document.querySelector(".md-header__topic .md-ellipsis");
    if (headerLogo && headerTitle) {
      headerTitle.style.cursor = "pointer";
      headerTitle.addEventListener("click", function () {
        window.location.href = headerLogo.getAttribute("href");
      });
    }

    var sidebarLogo = document.querySelector(".md-nav--primary > label.md-nav__title[for='__drawer'] > a.md-logo");
    var sidebarLabel = document.querySelector(".md-nav--primary > label.md-nav__title[for='__drawer']");
    if (sidebarLogo && sidebarLabel) {
      sidebarLabel.style.cursor = "pointer";
      sidebarLabel.addEventListener("click", function (e) {
        if (e.target.closest(".md-logo")) return;
        window.location.href = sidebarLogo.getAttribute("href");
      });
    }

    // The sidebar site title's text is a bare text node (not wrapped in
    // .md-ellipsis like every other link), so wrap it the same way the
    // numbers get wrapped below -- lets the collapsed rail hide it too,
    // leaving just the logo icon.
    if (sidebarLabel) {
      var titleNode = Array.prototype.find.call(sidebarLabel.childNodes, function (n) {
        return n.nodeType === Node.TEXT_NODE && n.textContent.trim();
      });
      if (titleNode) {
        var siteTitle = document.createElement("span");
        siteTitle.className = "nav-title";
        siteTitle.textContent = titleNode.textContent;
        titleNode.replaceWith(siteTitle);
      }
    }

    // Split "12.1. Off-Net Security Verification" into a number span and a
    // title span, so the collapsed rail (below) can hide just the title.
    document.querySelectorAll(".md-nav--primary .md-ellipsis").forEach(function (el) {
      var text = el.textContent.trim();
      var m = text.match(/^(\d+(?:\.\d+)*\.)\s*(.*)$/);
      if (!m) return;
      el.textContent = "";
      var num = document.createElement("span");
      num.className = "nav-num";
      num.textContent = m[1];
      var title = document.createElement("span");
      title.className = "nav-title";
      title.textContent = " " + m[2];
      el.appendChild(num);
      el.appendChild(title);
    });

    // Collapsible left nav: a toggle button shrinks the sidebar down to a
    // minimal rail showing only chapter numbers, remembered across pages.
    var COLLAPSE_KEY = "navCollapsed";
    var collapsed = localStorage.getItem(COLLAPSE_KEY) === "1";

    function applyCollapsed(value) {
      document.documentElement.classList.toggle("nav-collapsed", value);
      if (toggleBtn) toggleBtn.textContent = value ? "›" : "‹";
    }

    var sidebar = document.querySelector(".md-sidebar--primary .md-sidebar__inner") || document.querySelector(".md-sidebar--primary");
    var toggleBtn = document.createElement("button");
    toggleBtn.className = "nav-collapse-toggle";
    toggleBtn.setAttribute("aria-label", "Collapse navigation");
    toggleBtn.type = "button";
    if (sidebar) sidebar.insertBefore(toggleBtn, sidebar.firstChild);

    applyCollapsed(collapsed);

    toggleBtn.addEventListener("click", function () {
      collapsed = !collapsed;
      localStorage.setItem(COLLAPSE_KEY, collapsed ? "1" : "0");
      applyCollapsed(collapsed);
    });
  });
})();
