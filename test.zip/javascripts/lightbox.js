(function () {
  function closeLightbox() {
    var overlay = document.querySelector(".lightbox-overlay");
    if (overlay) overlay.remove();
    document.body.style.overflow = "";
  }

  function openLightbox(img) {
    var overlay = document.createElement("div");
    overlay.className = "lightbox-overlay";

    var enlarged = document.createElement("img");
    enlarged.src = img.currentSrc || img.src;
    enlarged.alt = img.alt || "";

    var closeBtn = document.createElement("button");
    closeBtn.className = "lightbox-close";
    closeBtn.setAttribute("aria-label", "Close");
    closeBtn.textContent = "×";

    overlay.appendChild(enlarged);
    overlay.appendChild(closeBtn);
    document.body.appendChild(overlay);
    document.body.style.overflow = "hidden";

    overlay.addEventListener("click", function (e) {
      if (e.target === overlay) closeLightbox();
    });
    closeBtn.addEventListener("click", closeLightbox);
  }

  document.addEventListener("click", function (e) {
    var img = e.target.closest(".md-typeset img");
    if (!img || img.closest(".hero-banner")) return;
    openLightbox(img);
  });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") closeLightbox();
  });
})();
